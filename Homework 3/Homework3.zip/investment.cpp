class Investment 
{
public:
	Investment(string name, int price)
		: name_(name), price_(price) {}
	virtual ~Investment() 
		{}
	
	int purchasePrice() const
		{ return price_; }
	string name() const
		{ return name_; }
	virtual bool fungible() const
		{return false; }

	virtual string description() const = 0;

private:
	string name_;
	int price_;
};

class Painting : public Investment 
{
public:
	Painting(string name, int price) 
		: Investment(name, price) {};
	~Painting()
		{ cout << "Destroying " << name() << ", a painting" << endl; }
	virtual string description() const
	 { return "painting"; }
};

class Stock : public Investment 
{
public:
	Stock(string name, int price, string ticker)
		: Investment(name, price), ticker_(ticker) {};
	~Stock()
		{ cout << "Destroying " << name() << ", a stock holding" << endl; }
	virtual bool fungible() const
		{ return true; }
	virtual string description() const
		{ return "stock trading as " + ticker_; }

private:
	string ticker_;
};

class House : public Investment 
{
public:
	House(string name, int price)
		: Investment(name, price) {};
	~House()
		{ cout << "Destroying the house " << name() << endl; }
	virtual string description() const
		{ return "house"; }
};
